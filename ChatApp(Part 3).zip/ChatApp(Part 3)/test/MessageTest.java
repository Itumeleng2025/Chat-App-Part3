/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

/**
 *
 * @author  ST10445362 Nyakane Itumeleng 
 */
import chatapp.part.pkg1.Message;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class MessageTest {

    private Message msg1, msg2, msg3, msg4, msg5;

    @Before
    public void setUp() {
        // Reset static state before each test to ensure isolation
        Message.resetForTesting();

        // Create test messages
        msg1 = new Message("+27834557896", "Did you get the cake?");
        msg2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        msg3 = new Message("+27834484567", "Yohoooo, I am at your gate.");
        msg4 = new Message("0838884567", "It is dinner time !");
        msg5 = new Message("+27838884567", "Ok, I am leaving without you.");

        // Process messages into static lists
        msg1.processMessageOption(1); // Sent
        msg2.processMessageOption(3); // Stored
        msg3.processMessageOption(2); // Disregarded
        msg4.processMessageOption(1); // Sent
        msg5.processMessageOption(3); // Stored
    }

    @Test
    public void testSentMessages() {
        ArrayList<Message> sent = Message.getSentMessages();
        assertEquals(2, sent.size());
        assertEquals("Did you get the cake?", sent.get(0).getMessageText());
        assertEquals("It is dinner time !", sent.get(1).getMessageText());
    }

    @Test
    public void testLongestMessage() {
        ArrayList<Message> allMessages = Message.getAllMessages();
        Message longest = allMessages.stream()
            .max((m1, m2) -> Integer.compare(m1.getMessageText().length(), m2.getMessageText().length()))
            .orElse(null);
        assertNotNull(longest);
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest.getMessageText());
    }

    @Test
    public void testSearchByMessageID() {
        String id = msg4.getMessageID();
        ArrayList<Message> sent = Message.getSentMessages();
        Message found = sent.stream()
            .filter(m -> m.getMessageID().equals(id))
            .findFirst()
            .orElse(null);
        assertNotNull(found);
        assertEquals("It is dinner time !", found.getMessageText());
    }

    @Test
    public void testSearchByRecipient() {
        ArrayList<Message> stored = Message.getStoredMessages();
        ArrayList<Message> matches = new ArrayList<>();
        for (Message m : stored) {
            if (m.getRecipient().equals("+27838884567")) {
                matches.add(m);
            }
        }
        assertEquals(2, matches.size());
        assertEquals("Where are you? You are late! I have asked you to be on time.", matches.get(0).getMessageText());
        assertEquals("Ok, I am leaving without you.", matches.get(1).getMessageText());
    }

    @Test
    public void testDeleteMessageByHash() {
        String hash = msg2.getMessageHash();
        ArrayList<Message> stored = Message.getStoredMessages();
        boolean removed = stored.removeIf(m -> m.getMessageHash().equals(hash));
        assertTrue(removed);
        assertEquals(1, stored.size());
        assertEquals("Ok, I am leaving without you.", stored.get(0).getMessageText());
    }

    @Test
    public void testDisplayReport() {
        ArrayList<Message> sent = Message.getSentMessages();
        StringBuilder sb = new StringBuilder();
        for (Message m : sent) {
            sb.append("Message Hash: ").append(m.getMessageHash()).append("\n");
            sb.append("Recipient: ").append(m.getRecipient()).append("\n");
            sb.append("Message: ").append(m.getMessageText()).append("\n\n");
        }
        String output = sb.toString();
        assertTrue(output.contains(msg1.getMessageText()));
        assertTrue(output.contains(msg4.getMessageText()));
        assertTrue(output.contains(msg1.getMessageHash()));
        assertTrue(output.contains(msg4.getMessageHash()));
    }
}