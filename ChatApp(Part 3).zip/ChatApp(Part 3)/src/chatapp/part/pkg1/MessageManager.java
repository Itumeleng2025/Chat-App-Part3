/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;

/**
 *
 * @author  ST10445362 Nyakane Itumeleng 
 */
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MessageManager class provides a simple GUI for managing messages.
 * It allows loading, searching, deleting, and saving messages using Java Swing and manual JSON file handling.
 */
public class MessageManager {
    private static List<Message> loadedMessages = new ArrayList<>(); // List to hold loaded messages
    private static JFrame frame; // Main GUI frame
    private static JTextArea displayArea; // Area to display messages
    private static JTextField searchField; // Field for entering search ID
    private static JButton loadButton, searchButton, deleteButton, saveButton, listIdsButton; // GUI buttons

    // Main method to launch the GUI
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    // Creates and displays the GUI
    private static void createAndShowGUI() {
        frame = new JFrame("Message Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());

        loadButton = new JButton("Load Messages");
        loadButton.addActionListener(e -> loadMessages());
        panel.add(loadButton);

        searchField = new JTextField(20);
        panel.add(searchField);

        searchButton = new JButton("Search by ID");
        searchButton.addActionListener(e -> searchMessage());
        panel.add(searchButton);

        deleteButton = new JButton("Delete by ID");
        deleteButton.addActionListener(e -> deleteMessage());
        panel.add(deleteButton);

        saveButton = new JButton("Save Messages");
        saveButton.addActionListener(e -> saveMessages());
        panel.add(saveButton);

        listIdsButton = new JButton("List IDs");
        listIdsButton.addActionListener(e -> listMessageIds());
        panel.add(listIdsButton);

        frame.add(panel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    // Loads messages from messages.json file into loadedMessages list using manual JSON parsing
    private static void loadMessages() {
        loadedMessages.clear();
        try {
            String content = readFileAsString("messages.json").trim();
            if (!content.isEmpty() && content.startsWith("[") && content.endsWith("]")) {
                String inner = content.substring(1, content.length() - 1).trim();
                if (!inner.isEmpty()) {
                    String[] objects = inner.split("\\},\\s*\\{");
                    for (String objStr : objects) {
                        objStr = objStr.replaceAll("^\\{|\\}$", ""); // Remove leading/trailing braces
                        String[] pairs = objStr.split(",");
                        String id = null, recipient = null, hash = null, text = null;
                        for (String pair : pairs) {
                            String[] keyValue = pair.split(":", 2);
                            if (keyValue.length == 2) {
                                String key = keyValue[0].replaceAll("\"", "").trim();
                                String value = keyValue[1].replaceAll("^\"", "").replaceAll("\"$", "").trim();
                                switch (key) {
                                    case "MessageID": id = value; break;
                                    case "Recipient": recipient = value; break;
                                    case "MessageHash": hash = value; break;
                                    case "Message": text = value.replace("\\\"", "\"").replace("\\n", "\n").replace("\\r", "\r"); break;
                                }
                            }
                        }
                        if (id != null && recipient != null && hash != null && text != null) {
                            Message msg = new Message(id, hash, recipient, text);
                            loadedMessages.add(msg);
                        }
                    }
                }
            }
            displayMessages();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Error loading messages: " + e.getMessage());
        }
    }

    // Displays all loaded messages in the text area
    private static void displayMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message msg : loadedMessages) {
            sb.append(msg.printMessages()).append("\n\n");
        }
        displayArea.setText(sb.toString());
    }

    // Searches for a message by ID and displays it (refined: case-insensitive, trimmed, with better feedback)
    private static void searchMessage() {
        String id = searchField.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid Message ID to search.");
            return;
        }
        for (Message msg : loadedMessages) {
            if (msg.messageID.trim().equalsIgnoreCase(id)) {
                displayArea.setText(msg.printMessages());
                return;
            }
        }
        // If not found, show available IDs for debugging
        StringBuilder availableIds = new StringBuilder("Message not found for ID: " + id + "\n\nAvailable IDs:\n");
        for (Message msg : loadedMessages) {
            availableIds.append(msg.messageID).append("\n");
        }
        JOptionPane.showMessageDialog(frame, availableIds.toString());
    }

    // Deletes a message by ID from the list (refined: case-insensitive, trimmed)
    private static void deleteMessage() {
        String id = searchField.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid Message ID to delete.");
            return;
        }
        boolean removed = loadedMessages.removeIf(msg -> msg.messageID.trim().equalsIgnoreCase(id));
        displayMessages();
        if (removed) {
            JOptionPane.showMessageDialog(frame, "Message deleted.");
        } else {
            JOptionPane.showMessageDialog(frame, "Message not found for ID: " + id);
        }
    }

    // Saves loaded messages to messages.json file using manual JSON building
    private static void saveMessages() {
        StringBuilder json = new StringBuilder("[");
        for (int i = 0; i < loadedMessages.size(); i++) {
            Message msg = loadedMessages.get(i);
            String escapedMessage = msg.getMessageText().replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
            json.append("{\"MessageID\":\"").append(msg.messageID).append("\",\"MessageHash\":\"").append(msg.messageHash)
                .append("\",\"Recipient\":\"").append(msg.recipient).append("\",\"Message\":\"").append(escapedMessage).append("\"}");
            if (i < loadedMessages.size() - 1) {
                json.append(",");
            }
        }
        json.append("]");
        writeStringToFile("messages.json", json.toString());
        JOptionPane.showMessageDialog(frame, "Messages saved.");
    }

    // Lists all message IDs in the display area
    private static void listMessageIds() {
        StringBuilder sb = new StringBuilder("Message IDs:\n");
        for (Message msg : loadedMessages) {
            sb.append(msg.messageID).append("\n");
        }
        displayArea.setText(sb.toString());
    }

    // Helper: Reads file content as string
    private static String readFileAsString(String fileName) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            return "";
        }
        return content.toString();
    }

    // Helper: Writes string content to file
    private static void writeStringToFile(String fileName, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(content);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving: " + e.getMessage());
        }
    }
}