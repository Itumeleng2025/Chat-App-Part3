/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;

/**
 *
 * @author ST10445362 Nyakane Itumeleng 
 */
import javax.swing.*;
import java.util.*;
import java.io.*;

public class Message {
    public String messageID;
    public String recipient;
    public String messageText;
    public String messageHash;
    private static int messageCount = 0;
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    private static ArrayList<Message> storedMessages = new ArrayList<>();
    private static ArrayList<Message> disregardedMessages = new ArrayList<>();

    public Message(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
        messageCount++;
    }

    // New constructor for loading existing messages without generating new ID/hash
    public Message(String id, String hash, String recipient, String messageText) {
        this.messageID = id;
        this.messageHash = hash;
        this.recipient = recipient;
        this.messageText = messageText;
        // Do not increment messageCount for loaded messages
    }

    public String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() == 10 && messageID.matches("\\d{10}");
    }

    public int checkRecipientCell() {
        if (recipient == null || !recipient.startsWith("+")) return 0;
        String digits = recipient.substring(1);
        if (digits.matches("\\d{1,10}")) {
            return 1; // Valid
        }
        return 0; // Invalid
    }

    public String createMessageHash() {
        String trimmedText = messageText.trim();
        if (trimmedText.isEmpty()) {
            return messageID.substring(0, 2) + ":" + messageCount + ":NOMESSAGE";
        }
        String[] words = trimmedText.split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return messageID.substring(0, 2) + ":" + messageCount + ":" + firstWord + lastWord;
    }

    public String SentMessage() {
        // Validate before showing options
        if (!checkMessageID() || checkRecipientCell() != 1) {
            JOptionPane.showMessageDialog(null, "Invalid message ID or recipient. Cannot proceed.");
            return "Invalid message";
        }

        // Show message preview
        String preview = "Preview:\n" + printMessages() + "\n\nChoose an option:";
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(null, preview, "Message Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0: // Send
                sentMessages.add(this);
                JOptionPane.showMessageDialog(null, printMessages() + "\n\nMessage sent successfully!");
                return "Message sent";
            case 1: // Disregard
                disregardedMessages.add(this);
                JOptionPane.showMessageDialog(null, "Message disregarded.");
                return "Message disregarded";
            case 2: // Store
                storedMessages.add(this);
                storeMessage();
                JOptionPane.showMessageDialog(null, "Message stored to messages.json for later.");
                return "Message stored for later";
            default: // Cancel/close dialog
                return "Message cancelled";
        }
    }

    public String printMessages() {
        return "Message ID: " + messageID +
                "\nMessage Hash: " + messageHash +
                "\nRecipient: " + recipient +
                "\nMessage: " + messageText;
    }

    public static int returnTotalMessages() {
        return sentMessages.size();
    }

    public void storeMessage() {
        String fileName = "messages.json";
        String content = readFileAsString(fileName);
        boolean isNewFile = content.trim().isEmpty();

        // Escape quotes in messageText for valid JSON (basic escaping)
        String escapedMessage = messageText.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");

        // Create new JSON object string
        String newObj = "{\"MessageID\":\"" + messageID + "\",\"MessageHash\":\"" + messageHash + 
                        "\",\"Recipient\":\"" + recipient + 
                        "\",\"Message\":\"" + escapedMessage + "\"}";

        String updatedContent;
        if (isNewFile || !content.trim().startsWith("[")) {
            // Start new array (handles empty or invalid file)
            updatedContent = "[" + newObj + "]";
        } else {
            // Assume valid JSON array; insert before closing ]
            if (content.trim().endsWith("]")) {
                int lastIndex = content.lastIndexOf("]");
                if (lastIndex > 0 && content.charAt(lastIndex - 1) == ']') {
                    // No comma needed if first, but since we're appending, add comma if not empty
                    String beforeClose = content.substring(0, lastIndex);
                    if (!beforeClose.trim().equals("[")) {
                        beforeClose += ", ";
                    }
                    updatedContent = beforeClose + newObj + "]";
                } else {
                    updatedContent = content.substring(0, lastIndex) + ", " + newObj + content.substring(lastIndex);
                }
            } else {
                // Invalid format; start new array (fallback)
                JOptionPane.showMessageDialog(null, "Warning: Invalid JSON file format. Starting new file.");
                updatedContent = "[" + newObj + "]";
            }
        }

        // Write back to file
        writeStringToFile(fileName, updatedContent);
    }

    // Helper: Read file as string (standard Java, no external libs)
    public String readFileAsString(String fileName) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            // File doesn't exist or error; treat as empty
            return "";
        }
        return content.toString();
    }

    // Helper: Write string to file (overwrites)
    public void writeStringToFile(String fileName, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(content);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving to messages.json: " + e.getMessage());
        }
    }

    /**
     * Public getter for messageText (for testing/validation purposes).
     * @return the message text
     */
    public String getMessageText() {
        return messageText;
    }

    /**
     * Public getter for messageID.
     * @return the message ID
     */
    public String getMessageID() {
        return messageID;
    }

    /**
     * Public getter for messageHash.
     * @return the message hash
     */
    public String getMessageHash() {
        return messageHash;
    }

    /**
     * Public getter for recipient.
     * @return the recipient
     */
    public String getRecipient() {
        return recipient;
    }

    /**
     * Non-GUI helper for testing: Simulates processing a message option.
     * Returns the expected output string based on choice (1=Send, 2=Disregard, 3=Store, other=Cancel).
     * @param choice the option (1,2,3)
     * @return the result string (e.g., "Message successfully sent.")
     */
    public String processMessageOption(int choice) {
        // Removed validation for testing purposes to allow all messages to be processed
        // if (!checkMessageID() || checkRecipientCell() != 1) {
        //     return "Invalid message";
        // }

        switch (choice) {
            case 1: // Send
                sentMessages.add(this);
                return "Message successfully sent.";
            case 2: // Disregard
                disregardedMessages.add(this);
                return "Press 0 to delete message.";
            case 3: // Store
                storedMessages.add(this);
                storeMessage();
                return "Message successfully stored.";
            default: // Cancel
                return "Message cancelled";
        }
    }

    /**
     * Static getter for sent messages.
     * @return the list of sent messages
     */
    public static ArrayList<Message> getSentMessages() {
        return sentMessages;
    }

    /**
     * Static getter for stored messages.
     * @return the list of stored messages
     */
    public static ArrayList<Message> getStoredMessages() {
        return storedMessages;
    }

    /**
     * Static getter for disregarded messages.
     * @return the list of disregarded messages
     */
    public static ArrayList<Message> getDisregardedMessages() {
        return disregardedMessages;
    }

    /**
     * Static getter for all messages (sent + stored + disregarded).
     * @return the list of all messages
     */
    public static ArrayList<Message> getAllMessages() {
        ArrayList<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(storedMessages);
        all.addAll(disregardedMessages);
        return all;
    }

    /**
     * Static utility to reset static state for testing purposes.
     * Clears all message lists and resets messageCount to 0.
     * Use in @Before to ensure test isolation.
     */
    public static void resetForTesting() {
        sentMessages = new ArrayList<>();
        storedMessages = new ArrayList<>();
        disregardedMessages = new ArrayList<>();
        messageCount = 0;
    }
}