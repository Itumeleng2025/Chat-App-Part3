/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;

/**
 *
 * @author ST10445362 Nyakane Itumeleng 
 */
import java.util.*; // Added for List and ArrayList

// Stores and validates user details immutably
public class UserCredentials {

    // Fields are private to enforce encapsulation
    private String fullName;    // New field for full name
    private String username;
    private String password;
    private String phoneNumber;

    // Static list of registered users for validation (hardcoded for demo; load from DB/file in real app)
    private static List<UserCredentials> registeredUsers = new ArrayList<>();

    // Static initializer to add sample users
    static {
        // Sample user 1: Admin
        registeredUsers.add(new UserCredentials("Admin User", "admin", "password123", "+27123456789"));
        // Sample user 2: Test User
        registeredUsers.add(new UserCredentials("Test User", "user", "userpass", "+27891234567"));
    }

    /**
     * Constructor to initialize user credentials.
     * Throws IllegalArgumentException if any required field is null or empty.
     *
     * @param username the user's username
     * @param password the user's password
     * @param phoneNumber the user's phone number
     */
    public UserCredentials(String username, String password, String phoneNumber) {
        this(null, username, password, phoneNumber);
    }

    /**
     * Overloaded constructor including full name.
     *
     * @param fullName the user's full name (can be null or empty)
     * @param username the user's username
     * @param password the user's password
     * @param phoneNumber the user's phone number
     */
    public UserCredentials(String fullName, String username, String password, String phoneNumber) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username must not be null or empty");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password must not be null or empty");
        }
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Phone number must not be null or empty");
        }
        this.fullName = fullName;
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    // Getter and setter for fullName
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    // Getter and setter for username
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new IllegalArgumentException("Username must not be null or empty");
        }
        this.username = username;
    }

    // Getter and setter for password
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        if (password == null || password.trim().isEmpty()) {
            throw new IllegalArgumentException("Password must not be null or empty");
        }
        this.password = password;
    }

    // Getter and setter for phoneNumber
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Phone number must not be null or empty");
        }
        this.phoneNumber = phoneNumber;
    }

    /**
     * Static method to validate login credentials against registered users.
     * Checks if the provided username and password match any registered user.
     * (Ignores phoneNumber and fullName for login; case-sensitive match.)
     *
     * @param username the username to validate
     * @param password the password to validate
     * @return true if valid, false otherwise
     */
    public static boolean validateLogin(String username, String password) {
        if (username == null || password == null) {
            return false;
        }
        for (UserCredentials user : registeredUsers) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Optional: Static method to add a new user (for admin or registration; not used in login flow)
     *
     * @param fullName user's full name (can be null)
     * @param username user's username
     * @param password user's password
     * @param phoneNumber user's phone number
     */
    public static void addUser(String fullName, String username, String password, String phoneNumber) {
        try {
            registeredUsers.add(new UserCredentials(fullName, username, password, phoneNumber));
            System.out.println("User added successfully: " + username); // For logging
        } catch (IllegalArgumentException e) {
            System.err.println("Failed to add user: " + e.getMessage());
        }
    }

    /**
     * Returns a string representation of the user credentials.
     * Does not include password for security reasons.
     */
    @Override
    public String toString() {
        return "User Credentials{" +
                "fullName='" + fullName + '\'' +
                ", username='" + username + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                '}';
    }

    /**
     * Checks equality of two UserCredentials objects.
     * Two objects are equal if username, password, and phoneNumber are equal.
     *
     * @param o the object to compare
     * @return true if objects are equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // Same object reference
        if (!(o instanceof UserCredentials)) return false; // Check type
        UserCredentials that = (UserCredentials) o; // Cast safely
        return username.equals(that.username) &&
                password.equals(that.password) &&
                phoneNumber.equals(that.phoneNumber);
    }

    /**
     * Returns hash code based on username, password, and phoneNumber.
     * Required for collections like HashSet or HashMap.
     */
    @Override
    public int hashCode() {
        return java.util.Objects.hash(username, password, phoneNumber);
    }
}