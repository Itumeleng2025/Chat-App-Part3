/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp.part.pkg1;


/**
 *
 * @author ST10445362 Nyakane Itumeleng 
 */

import javax.swing.*;

public class QuickChat {
    public static void startChat() {
        boolean loggedIn = login();
        if (!loggedIn) return;

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");

        while (true) {
            String choice = JOptionPane.showInputDialog(
                    "Choose an option:\n1) Send Messages\n2) Show recently sent messages\n3) Quit");

            if (choice == null) break; // User cancelled

            switch (choice.trim()) {
                case "1":
                    sendMessages();
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Goodbye.");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please enter 1, 2, or 3.");
            }
        }
    }

    private static boolean login() {
        String username = JOptionPane.showInputDialog("Enter username:");
        if (username == null) return false; // Cancelled

        String password = JOptionPane.showInputDialog("Enter password:");
        if (password == null) return false; // Cancelled

        // Connect this to your UserCredentials validation
        if (UserCredentials.validateLogin(username, password)) {
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Invalid username or password.");
            return false;
        }
    }

    private static void sendMessages() {
        String input = JOptionPane.showInputDialog("How many messages do you want to send?");
        if (input == null) return; // Cancelled

        int totalMessages;
        try {
            totalMessages = Integer.parseInt(input.trim());
            if (totalMessages <= 0) {
                JOptionPane.showMessageDialog(null, "Please enter a positive number.");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number. Please enter a valid positive integer.");
            return;
        }

        for (int i = 0; i < totalMessages; i++) {
            // Validate recipient (must start with +, followed by 1-10 digits, total length <=11)
            String recipient = null;
            while (true) {
                recipient = JOptionPane.showInputDialog("Enter recipient cell number (must start with + followed by 1-10 digits, e.g., +2783123456):");
                if (recipient == null) return; // Cancel out of entire loop
                if (recipient.startsWith("+") && recipient.length() <= 11 && recipient.substring(1).matches("\\d{1,10}")) {
                    break;
                }
                JOptionPane.showMessageDialog(null, "Invalid recipient. Must start with + followed by 1-10 digits only (no letters or special chars).");
            }

            // Validate message text (1-250 chars including spaces, non-empty after trim)
            String messageText = null;
            while (true) {
                messageText = JOptionPane.showInputDialog("Enter message text (max 250 characters):");
                if (messageText == null) return; // Cancel out
                String trimmed = messageText.trim();
                if (!trimmed.isEmpty() && messageText.length() <= 250) {
                    // messageText is already the original with spaces; no need for 'this' assignment
                    break;
                }
                JOptionPane.showMessageDialog(null, "Invalid message. Must be 1-250 characters long (including spaces) and non-empty.");
            }

            Message msg = new Message(recipient, messageText);
            String result = msg.SentMessage();
            if ("Message cancelled".equals(result) || "Invalid message".equals(result)) {
                i--; // Retry this message if cancelled or invalid
            }
        }

        JOptionPane.showMessageDialog(null, "Total messages sent: " + Message.returnTotalMessages());
    }
}